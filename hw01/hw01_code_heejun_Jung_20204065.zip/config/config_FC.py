class FC_config():
    def __init__(self,
                 input_size=784,
                 hidden_size=1024,
                 num_hidden_layers=2,
                 num_classes=10):
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.num_hidden_layers = num_hidden_layers
        self.num_classes = num_classes